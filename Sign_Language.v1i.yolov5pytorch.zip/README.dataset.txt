# Sign_Language > 2024-04-02 10:39pm
https://universe.roboflow.com/signlanguagedetection-kxco1/sign_language-dafjx

Provided by a Roboflow user
License: CC BY 4.0

